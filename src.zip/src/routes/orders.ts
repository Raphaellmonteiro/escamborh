// src/routes/orders.ts
import { Router, Request } from 'express';
import { pool, q1, qAll, qRun, qInsert, withTx, txQ1, txQAll, txRun, txInsert } from '../db';
import { gerarCupomHtml } from './print';

export function createOrdersRouter() {
  const router = Router();

  router.post('/', async (req: Request, res) => {
    try {
      const { items, payments, observation, total_amount, tipo_retirada } = req.body;
      const TZ = 'America/Sao_Paulo';
      
      // CORREÇÃO 1: Puxa a contagem de pedidos usando o fuso de SP
      const todayRow = await q1(
        `SELECT COUNT(*) as count FROM pedidos WHERE (created_at AT TIME ZONE '${TZ}')::date = (NOW() AT TIME ZONE '${TZ}')::date AND tenant_id=?`,
        [req.tenantId]
      );
      const nextNumber = Number(todayRow?.count || 0) + 1;
      
      // CORREÇÃO 2: Cria o código do pedido com a data do Brasil
      const dateObj = new Date(new Date().toLocaleString("en-US", { timeZone: TZ }));
      const y = String(dateObj.getFullYear()).slice(-2);
      const m = String(dateObj.getMonth() + 1).padStart(2, '0');
      const d = String(dateObj.getDate()).padStart(2, '0');
      const dateStr = `${y}${m}${d}`;
      
      const orderNumber= `${dateStr}-${req.tenantId}-${nextNumber.toString().padStart(3,'0')}`;

      const result = await withTx(async (client) => {
        const senhaPedido = nextNumber;
        const tipoRet = tipo_retirada || 'local';
        const orderId = await txInsert(client,
          'INSERT INTO pedidos (order_number,total_amount,observation,tenant_id,senha_pedido,tipo_retirada) VALUES (?,?,?,?,?,?)',
          [orderNumber, total_amount, observation, req.tenantId, senhaPedido, tipoRet]
        );

        for (const item of items) {
          await txRun(client,
            'INSERT INTO itens_pedido (order_id,product_id,quantity,type,price_at_time,tenant_id) VALUES (?,?,?,?,?,?)',
            [orderId, item.product_id, item.quantity, item.type, item.price_at_time, req.tenantId]
          );
        }

        // Baixa de estoque automática
        for (const item of items) {
          const prod = await txQ1(client, 'SELECT * FROM produtos WHERE id=? AND tenant_id=?', [item.product_id, req.tenantId]);
          if (!prod) continue;
          if (prod.codigo_barras) {
            const ing = await txQ1(client,
              'SELECT * FROM ingredientes WHERE tenant_id=? AND (codigo_barras=? OR LOWER(nome)=LOWER(?)) LIMIT 1',
              [req.tenantId, prod.codigo_barras, prod.name]
            );
            if (ing) {
              await txRun(client, 'UPDATE ingredientes SET estoque_atual=GREATEST(0,estoque_atual-?) WHERE id=? AND tenant_id=?', [item.quantity, ing.id, req.tenantId]);
              await txRun(client, "INSERT INTO estoque_movimentacoes (ingrediente_id,tipo,quantidade,motivo,tenant_id) VALUES (?,'saida',?,'Venda automática',?)", [ing.id, item.quantity, req.tenantId]);
              continue;
            }
          }
          const vinculos = await txQAll(client, 'SELECT * FROM produto_ingrediente WHERE product_id=? AND tenant_id=?', [item.product_id, req.tenantId]);
          for (const v of vinculos) {
            const qtd = v.quantidade_usada * item.quantity;
            await txRun(client, 'UPDATE ingredientes SET estoque_atual=GREATEST(0,estoque_atual-?) WHERE id=? AND tenant_id=?', [qtd, v.ingrediente_id, req.tenantId]);
            await txRun(client, "INSERT INTO estoque_movimentacoes (ingrediente_id,tipo,quantidade,motivo,tenant_id) VALUES (?,'saida',?,'Venda automática',?)", [v.ingrediente_id, qtd, req.tenantId]);
          }
        }

        for (const p of payments) {
          await txRun(client,
            'INSERT INTO pagamentos (order_id,method,amount_paid,change_given,tenant_id) VALUES (?,?,?,?,?)',
            [orderId, p.method, p.amount_paid, p.change_given||0, req.tenantId]
          );
        }

        // Gerar cupom HTML
        const now = new Date().toLocaleString('pt-BR', { timeZone:'America/Sao_Paulo', day:'2-digit', month:'2-digit', year:'2-digit', hour:'2-digit', minute:'2-digit' });
        const clienteRow = await txQ1(client, 'SELECT nome_estabelecimento FROM clientes WHERE id=?', [req.tenantId]);
        const prodIds = items.map((i: any) => i.product_id);
        const prodRows = await txQAll(client,
          `SELECT id, name FROM produtos WHERE id IN (${prodIds.map(() => '?').join(',')}) AND tenant_id=?`,
          [...prodIds, req.tenantId]
        );
        const prodMap: Record<number, string> = {};
        for (const p of prodRows) prodMap[p.id] = p.name;
        const itensParaCupom = items.map((item: any) => ({
          qtd: item.quantity, nome: prodMap[item.product_id] || 'Produto', valor: item.price_at_time * item.quantity,
        }));
        const receiptHtml = gerarCupomHtml({
          titulo: 'RECIBO', estabelecimento: clienteRow?.nome_estabelecimento || 'FlowPDV',
          orderNumber, data: now, itens: itensParaCupom,
          totais: [{ label: 'TOTAL', valor: total_amount, destaque: true }],
          pagamentos: payments.map((p: any) => ({ metodo: p.method, valor: p.amount_paid, troco: p.change_given > 0 ? p.change_given : undefined })),
          rodape: observation?.trim() ? `Obs: ${observation.trim()}` : undefined,
        });
        await txRun(client, 'UPDATE pedidos SET receipt_text=? WHERE id=? AND tenant_id=?', [receiptHtml, orderId, req.tenantId]);
        return { orderId, orderNumber, receipt: receiptHtml, senhaPedido };
      });

      res.json({ success: true, ...result });
    } catch (err: any) {
      console.error('POST /orders erro:', err.message);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  router.get('/', async (req: Request, res) => {
    try {
      const { day, month, year, status, limit } = req.query;
      const TZ = 'America/Sao_Paulo';

      let q = `SELECT p.*,
        ip.id as _iid, ip.product_id as _pid, ip.quantity as _qty,
        ip.type as _type, ip.price_at_time as _price,
        pr.name as _pname
        FROM pedidos p
        LEFT JOIN itens_pedido ip ON ip.order_id=p.id AND ip.tenant_id=p.tenant_id
        LEFT JOIN produtos pr ON pr.id=ip.product_id AND pr.tenant_id=p.tenant_id
        WHERE p.tenant_id=?`;
      const params: any[] = [req.tenantId];
      if (status) { q += ' AND p.status=?'; params.push(status); }

      if (!day && !month && !year) {
        // CORREÇÃO 3: Filtra corretamente pelo dia atual no fuso do Brasil
        q += ` AND (p.created_at AT TIME ZONE '${TZ}')::date = (NOW() AT TIME ZONE '${TZ}')::date`;
      } else {
        if (day && month && year) {
          q += ` AND (p.created_at AT TIME ZONE '${TZ}')::date = ?`;
          params.push(`${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`);
        } else if (month && year) {
          q += ` AND TO_CHAR(p.created_at AT TIME ZONE '${TZ}', 'MM')=? AND TO_CHAR(p.created_at AT TIME ZONE '${TZ}', 'YYYY')=?`;
          params.push(String(month).padStart(2,'0'), String(year));
        } else if (year) {
          q += ` AND TO_CHAR(p.created_at AT TIME ZONE '${TZ}', 'YYYY')=?`;
          params.push(String(year));
        }
      }
      q += ' ORDER BY p.created_at DESC, p.id DESC';
      if (limit) { q += ` LIMIT ${Number(limit) * 20}`; }

      const rows = await qAll(q, params);

      const pedidosMap = new Map<number, any>();
      for (const row of rows) {
        if (!pedidosMap.has(row.id)) {
          const { _iid, _pid, _qty, _type, _price, _pname, ...pedido } = row;
          // CORREÇÃO 4: Força a conversão do valor total para Número (Supabase manda String)
          pedidosMap.set(row.id, { 
            ...pedido, 
            total_amount: Number(pedido.total_amount || 0),
            items: [] 
          });
        }
        if (row._iid) {
          pedidosMap.get(row.id).items.push({
            product_id:    row._pid,
            product_name:  row._pname || 'Produto',
            quantity:      row._qty,
            type:          row._type,
            price_at_time: Number(row._price || 0),
          });
        }
      }

      let orders = Array.from(pedidosMap.values());
      if (limit) orders = orders.slice(0, Number(limit));
      res.json(orders);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // ── Despesas (antes de /:id) ──────────────────────────────────────────────
  router.get('/expenses', async (req: Request, res) => {
    const { month, year } = req.query;
    const TZ = 'America/Sao_Paulo';
    let q = "SELECT * FROM despesas WHERE tenant_id=?";
    const params: any[] = [req.tenantId];
    if (month && year) {
      q += ` AND TO_CHAR(created_at AT TIME ZONE '${TZ}', 'MM')=? AND TO_CHAR(created_at AT TIME ZONE '${TZ}', 'YYYY')=?`;
      params.push(String(month).padStart(2,'0'), String(year));
    }
    try { res.json(await qAll(q + ' ORDER BY created_at DESC', params)); }
    catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.post('/expenses', async (req: Request, res) => {
    const { description, amount, category } = req.body;
    try {
      const id = await qInsert('INSERT INTO despesas (description,amount,category,tenant_id) VALUES (?,?,?,?)',
        [description, amount, category||'Outros', req.tenantId]);
      res.json({ id, success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.delete('/expenses/:id', async (req: Request, res) => {
    try {
      await qRun('DELETE FROM despesas WHERE id=? AND tenant_id=?', [req.params.id, req.tenantId]);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.patch('/:id/status', async (req: Request, res) => {
    try {
      await qRun('UPDATE pedidos SET status=? WHERE id=? AND tenant_id=?', [req.body.status, req.params.id, req.tenantId]);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.delete('/:id', async (req: Request, res) => {
    try {
      const p = await q1('SELECT id FROM pedidos WHERE id=? AND tenant_id=?', [req.params.id, req.tenantId]);
      if (!p) return res.status(404).json({ error: 'Pedido não encontrado' });
      await qRun('DELETE FROM itens_pedido WHERE order_id=? AND tenant_id=?', [req.params.id, req.tenantId]);
      await qRun('DELETE FROM pagamentos WHERE order_id=? AND tenant_id=?', [req.params.id, req.tenantId]);
      await qRun('DELETE FROM pedidos WHERE id=? AND tenant_id=?', [req.params.id, req.tenantId]);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  return router;
}

// ── Router independente para /api/expenses ────────────────────────────────────
export function createExpensesRouter() {
  const router = Router();
  const TZ = 'America/Sao_Paulo';

  router.get('/', async (req: Request, res) => {
    const { month, year } = req.query;
    let q = "SELECT * FROM despesas WHERE tenant_id=?";
    const params: any[] = [req.tenantId];
    if (month && year) {
      q += ` AND TO_CHAR(created_at AT TIME ZONE '${TZ}', 'MM')=? AND TO_CHAR(created_at AT TIME ZONE '${TZ}', 'YYYY')=?`;
      params.push(String(month).padStart(2,'0'), String(year));
    }
    try { res.json(await qAll(q + ' ORDER BY created_at DESC', params)); }
    catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.post('/', async (req: Request, res) => {
    try {
      const { description, amount, category } = req.body;
      if (!description?.trim()) return res.status(400).json({ error: 'Descrição obrigatória' });
      if (!amount || isNaN(Number(amount))) return res.status(400).json({ error: 'Valor inválido' });
      const id = await qInsert('INSERT INTO despesas (description,amount,category,tenant_id) VALUES (?,?,?,?)',
        [description.trim(), Number(amount), category || 'Outros', req.tenantId]);
      res.json({ id, success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.delete('/:id', async (req: Request, res) => {
    try {
      await qRun('DELETE FROM despesas WHERE id=? AND tenant_id=?', [req.params.id, req.tenantId]);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  return router;
}
