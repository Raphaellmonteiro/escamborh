// src/routes/dashboard.ts
import { Router, Request } from 'express';
import { q1, qAll, qRun, qInsert } from '../db';

const TZ = 'America/Sao_Paulo';

export function createDashboardRouter() {
  const router = Router();

  router.get('/stats', async (req: Request, res) => {
    try {
      const { day, month, year } = req.query;

      // Filtro dinâmico para a query principal
      let dateFilter = `WHERE tenant_id=? AND (created_at AT TIME ZONE '${TZ}')::date = CURRENT_DATE`;
      const params: any[] = [req.tenantId];
      if (day && month && year) {
        dateFilter = `WHERE tenant_id=? AND (created_at AT TIME ZONE '${TZ}')::date = ?`;
        params.push(`${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`);
      } else if (month && year) {
        dateFilter = `WHERE tenant_id=? AND TO_CHAR(created_at AT TIME ZONE '${TZ}','MM')=? AND TO_CHAR(created_at AT TIME ZONE '${TZ}','YYYY')=?`;
        params.push(String(month).padStart(2,'0'), String(year));
      } else if (year) {
        dateFilter = `WHERE tenant_id=? AND TO_CHAR(created_at AT TIME ZONE '${TZ}','YYYY')=?`;
        params.push(String(year));
      }

      const [today, week, monthTotal, filteredTotal, totalExpenses] = await Promise.all([
        q1(`SELECT COALESCE(SUM(total_amount),0) as total FROM pedidos WHERE tenant_id=? AND (created_at AT TIME ZONE '${TZ}')::date = CURRENT_DATE`, [req.tenantId]),
        q1(`SELECT COALESCE(SUM(total_amount),0) as total FROM pedidos WHERE tenant_id=? AND (created_at AT TIME ZONE '${TZ}')::date >= CURRENT_DATE - INTERVAL '6 days'`, [req.tenantId]),
        q1(`SELECT COALESCE(SUM(total_amount),0) as total FROM pedidos WHERE tenant_id=? AND TO_CHAR(created_at AT TIME ZONE '${TZ}','MM-YYYY')=TO_CHAR(NOW() AT TIME ZONE '${TZ}','MM-YYYY')`, [req.tenantId]),
        q1(`SELECT COALESCE(SUM(total_amount),0) as total FROM pedidos ${dateFilter}`, params),
        q1(`SELECT COALESCE(SUM(amount),0) as total FROM despesas ${dateFilter.replace(/pedidos/g, 'despesas')}`, params),
      ]);

      // Produto mais vendido no período
      const productSalesFilter = dateFilter.replace('tenant_id=?', 'o.tenant_id=?')
        .replace(/created_at/g, 'o.created_at');
      const productSales = await qAll(
        `SELECT p.name, SUM(i.quantity) as quantity, SUM(i.quantity * i.price_at_time) as total
         FROM itens_pedido i JOIN produtos p ON i.product_id=p.id JOIN pedidos o ON i.order_id=o.id
         ${productSalesFilter} GROUP BY p.id, p.name ORDER BY quantity DESC`,
        params
      );

      // Repasses de funcionários no período
      let pfFilter = `WHERE pf.tenant_id=? AND (pf.created_at AT TIME ZONE '${TZ}')::date = CURRENT_DATE`;
      const pfParams: any[] = [req.tenantId];
      if (day && month && year) {
        pfFilter = `WHERE pf.tenant_id=? AND (pf.created_at AT TIME ZONE '${TZ}')::date = ?`;
        pfParams.push(`${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`);
      } else if (month && year) {
        pfFilter = `WHERE pf.tenant_id=? AND TO_CHAR(pf.created_at AT TIME ZONE '${TZ}','MM')=? AND TO_CHAR(pf.created_at AT TIME ZONE '${TZ}','YYYY')=?`;
        pfParams.push(String(month).padStart(2,'0'), String(year));
      } else if (year) {
        pfFilter = `WHERE pf.tenant_id=? AND TO_CHAR(pf.created_at AT TIME ZONE '${TZ}','YYYY')=?`;
        pfParams.push(String(year));
      }
      const totalRepassesPagos = await q1(
        `SELECT COALESCE(SUM(valor_repasse),0) as total FROM pagamentos_funcionarios pf ${pfFilter}`, pfParams
      );

      res.json({
        today: today?.total||0, week: week?.total||0, month: monthTotal?.total||0,
        filteredTotal: filteredTotal?.total||0, totalExpenses: totalExpenses?.total||0,
        totalRepassesPagos: totalRepassesPagos?.total||0, productSales,
      });
    } catch (e: any) { res.status(500).json({ error: e.message, productSales: [] }); }
  });

  router.get('/weekly', async (req: Request, res) => {
    try {
      const rows = await qAll(
        `SELECT (created_at AT TIME ZONE '${TZ}')::date as dia, COALESCE(SUM(total_amount),0) as total, COUNT(*) as pedidos
         FROM pedidos WHERE tenant_id=? AND (created_at AT TIME ZONE '${TZ}')::date >= CURRENT_DATE - INTERVAL '6 days'
         GROUP BY dia ORDER BY dia ASC`,
        [req.tenantId]
      );
      const result = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date(); d.setDate(d.getDate() - i);
        const dia = d.toISOString().slice(0,10);
        const found = rows.find((r: any) => r.dia?.toString().slice(0,10) === dia);
        result.push({ dia, label: d.toLocaleDateString('pt-BR', { weekday:'short', day:'2-digit' }), total: found?.total||0, pedidos: found?.pedidos||0 });
      }
      res.json(result);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.get('/cash-report', async (req: Request, res) => {
    const { day, month, year } = req.query;
    let dateFilter = `WHERE tenant_id=? AND (created_at AT TIME ZONE '${TZ}')::date = CURRENT_DATE`;
    const params: any[] = [req.tenantId];
    if (day && month && year) {
      dateFilter = `WHERE tenant_id=? AND (created_at AT TIME ZONE '${TZ}')::date = ?`;
      params.push(`${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`);
    } else if (month && year) {
      dateFilter = `WHERE tenant_id=? AND TO_CHAR(created_at AT TIME ZONE '${TZ}','MM')=? AND TO_CHAR(created_at AT TIME ZONE '${TZ}','YYYY')=?`;
      params.push(String(month).padStart(2,'0'), String(year));
    } else if (year) {
      dateFilter = `WHERE tenant_id=? AND TO_CHAR(created_at AT TIME ZONE '${TZ}','YYYY')=?`; params.push(String(year));
    }
    try {
      const report = await q1(
        `SELECT COALESCE(SUM(CASE WHEN method='Dinheiro' THEN amount_paid-change_given ELSE 0 END),0) as cash,
                COALESCE(SUM(CASE WHEN method='PIX'     THEN amount_paid ELSE 0 END),0) as pix,
                COALESCE(SUM(CASE WHEN method='Débito'  THEN amount_paid ELSE 0 END),0) as debit,
                COALESCE(SUM(CASE WHEN method='Crédito' THEN amount_paid ELSE 0 END),0) as credit,
                COALESCE(SUM(amount_paid-change_given),0) as total
         FROM pagamentos ${dateFilter}`,
        params
      );
      res.json(report || { cash:0, pix:0, debit:0, credit:0, total:0 });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // ── Caixa ─────────────────────────────────────────────────────────────────
  router.get('/hoje', async (req: Request, res) => {
    const today = new Date().toISOString().split('T')[0];
    res.json(await q1("SELECT * FROM caixa WHERE data=? AND tenant_id=?", [today, req.tenantId]) || null);
  });

  router.post('/abrir', async (req: Request, res) => {
    const { fundo_inicial, observacao } = req.body;
    const today = new Date().toISOString().split('T')[0];
    const existing = await q1("SELECT * FROM caixa WHERE data=? AND tenant_id=?", [today, req.tenantId]);
    if (existing) return res.status(400).json({ success: false, message: 'Caixa já foi aberto hoje.' });
    const id = await qInsert("INSERT INTO caixa (data,fundo_inicial,observacao,status,tenant_id) VALUES (?,?,?,'aberto',?)",
      [today, fundo_inicial, observacao||'', req.tenantId]);
    res.json({ success: true, id });
  });

  router.post('/fechar', async (req: Request, res) => {
    const { valor_contado, observacao } = req.body;
    const today = new Date().toISOString().split('T')[0];
    const caixa = await q1("SELECT * FROM caixa WHERE data=? AND status='aberto' AND tenant_id=?", [today, req.tenantId]);
    if (!caixa) return res.status(400).json({ success: false, message: 'Nenhum caixa aberto encontrado.' });
    const vd = await q1(
      `SELECT COALESCE(SUM(amount_paid-change_given),0) as total FROM pagamentos WHERE method='Dinheiro' AND (created_at AT TIME ZONE '${TZ}')::date=? AND tenant_id=?`,
      [today, req.tenantId]
    );
    const totalVD = vd.total;
    await qRun("UPDATE caixa SET valor_contado=?,status='fechado',observacao=?,closed_at=NOW() WHERE id=? AND tenant_id=?",
      [valor_contado, observacao||caixa.observacao, caixa.id, req.tenantId]);
    res.json({ success: true, total_vendas_dinheiro: totalVD, total_esperado: caixa.fundo_inicial+totalVD, diferenca: valor_contado-(caixa.fundo_inicial+totalVD) });
  });

  router.get('/historico', async (req: Request, res) => {
    const history = await qAll(
      `SELECT c.*, (SELECT COALESCE(SUM(amount_paid-change_given),0) FROM pagamentos WHERE method='Dinheiro' AND (created_at AT TIME ZONE '${TZ}')::date::text=c.data AND tenant_id=c.tenant_id) as total_vendas_dinheiro
       FROM caixa c WHERE c.tenant_id=? ORDER BY c.data DESC LIMIT 30`,
      [req.tenantId]
    );
    res.json(history.map((c: any) => ({
      ...c, total_esperado: c.fundo_inicial+c.total_vendas_dinheiro,
      diferenca: c.status==='fechado'?c.valor_contado-(c.fundo_inicial+c.total_vendas_dinheiro):null
    })));
  });

  return router;
}
