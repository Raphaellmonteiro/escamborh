// src/routes/estoque.ts
import { Router, Request } from 'express';
import { q1, qAll, qRun, qInsert } from '../db';

const TZ = 'America/Sao_Paulo';

export function createEstoqueRouter() {
  const router = Router();

  router.get('/', async (req: Request, res) => {
    try {
      res.json(await qAll(
        `SELECT i.*,
          COALESCE((SELECT SUM(quantidade) FROM estoque_movimentacoes WHERE ingrediente_id=i.id AND tipo='entrada' AND tenant_id=i.tenant_id),0) as total_entrada,
          COALESCE((SELECT SUM(quantidade) FROM estoque_movimentacoes WHERE ingrediente_id=i.id AND tipo='saida'   AND tenant_id=i.tenant_id),0) as total_saida
         FROM ingredientes i WHERE i.tenant_id=? ORDER BY i.nome ASC`,
        [req.tenantId]
      ));
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.post('/', async (req: Request, res) => {
    try {
      const { nome, unidade, estoque_atual, estoque_minimo, custo_unitario, fornecedor, codigo_barras } = req.body;
      if (!nome?.trim() || !unidade?.trim()) return res.status(400).json({ error: 'Nome e unidade obrigatórios' });
      const id = await qInsert(
        'INSERT INTO ingredientes (nome,unidade,estoque_atual,estoque_minimo,custo_unitario,fornecedor,codigo_barras,tenant_id) VALUES (?,?,?,?,?,?,?,?)',
        [nome.trim(), unidade.trim(), estoque_atual||0, estoque_minimo||0, custo_unitario||0, fornecedor||null, codigo_barras||null, req.tenantId]
      );
      res.json({ id, success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.put('/:id', async (req: Request, res) => {
    try {
      const { nome, unidade, estoque_minimo, custo_unitario, fornecedor, codigo_barras } = req.body;
      await qRun('UPDATE ingredientes SET nome=?,unidade=?,estoque_minimo=?,custo_unitario=?,fornecedor=?,codigo_barras=? WHERE id=? AND tenant_id=?',
        [nome, unidade, estoque_minimo||0, custo_unitario||0, fornecedor||null, codigo_barras||null, req.params.id, req.tenantId]);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.delete('/:id', async (req: Request, res) => {
    try {
      await qRun('DELETE FROM estoque_movimentacoes WHERE ingrediente_id=? AND tenant_id=?', [req.params.id, req.tenantId]);
      await qRun('DELETE FROM ingredientes WHERE id=? AND tenant_id=?', [req.params.id, req.tenantId]);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.post('/:id/movimentacao', async (req: Request, res) => {
    try {
      const { tipo, quantidade, motivo } = req.body;
      if (!tipo || !quantidade) return res.status(400).json({ error: 'tipo e quantidade obrigatórios' });
      const ing = await q1('SELECT * FROM ingredientes WHERE id=? AND tenant_id=?', [req.params.id, req.tenantId]);
      if (!ing) return res.status(404).json({ error: 'Ingrediente não encontrado' });
      const novoEstoque = tipo === 'entrada'
        ? ing.estoque_atual + Number(quantidade)
        : Math.max(0, ing.estoque_atual - Number(quantidade));
      await qRun('UPDATE ingredientes SET estoque_atual=? WHERE id=? AND tenant_id=?', [novoEstoque, req.params.id, req.tenantId]);
      await qRun('INSERT INTO estoque_movimentacoes (ingrediente_id,tipo,quantidade,motivo,tenant_id) VALUES (?,?,?,?,?)',
        [req.params.id, tipo, quantidade, motivo||null, req.tenantId]);
      res.json({ success: true, estoque_atual: novoEstoque });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.get('/movimentacoes/hoje', async (req: Request, res) => {
    try {
      res.json(await qAll(
        `SELECT m.*, i.nome as ingrediente_nome, i.unidade
         FROM estoque_movimentacoes m JOIN ingredientes i ON m.ingrediente_id=i.id
         WHERE m.tenant_id=? AND (m.created_at AT TIME ZONE '${TZ}')::date = CURRENT_DATE
         ORDER BY m.created_at DESC`,
        [req.tenantId]
      ));
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.get('/movimentacoes/periodo', async (req: Request, res) => {
    try {
      const { inicio, fim } = req.query;
      res.json(await qAll(
        `SELECT m.*, i.nome as ingrediente_nome, i.unidade
         FROM estoque_movimentacoes m JOIN ingredientes i ON m.ingrediente_id=i.id
         WHERE m.tenant_id=? AND (m.created_at AT TIME ZONE '${TZ}')::date BETWEEN ? AND ?
         ORDER BY m.created_at DESC`,
        [req.tenantId, inicio, fim]
      ));
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.get('/:id/historico', async (req: Request, res) => {
    try {
      res.json(await qAll('SELECT * FROM estoque_movimentacoes WHERE ingrediente_id=? AND tenant_id=? ORDER BY created_at DESC LIMIT 50', [req.params.id, req.tenantId]));
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.get('/relatorio/consumo', async (req: Request, res) => {
    try {
      const { inicio, fim } = req.query;
      res.json(await qAll(
        `SELECT i.nome, i.unidade,
           COALESCE(SUM(CASE WHEN m.tipo='saida' THEN m.quantidade ELSE 0 END),0) as total_consumido,
           COALESCE(SUM(CASE WHEN m.tipo='entrada' THEN m.quantidade ELSE 0 END),0) as total_entrada,
           i.estoque_atual, i.estoque_minimo
         FROM ingredientes i
         LEFT JOIN estoque_movimentacoes m ON m.ingrediente_id=i.id AND m.tenant_id=i.tenant_id
           AND (m.created_at AT TIME ZONE '${TZ}')::date BETWEEN ? AND ?
         WHERE i.tenant_id=? GROUP BY i.id, i.nome, i.unidade, i.estoque_atual, i.estoque_minimo ORDER BY total_consumido DESC`,
        [inicio||'1900-01-01', fim||'2100-12-31', req.tenantId]
      ));
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.get('/ficha-tecnica/:product_id', async (req: Request, res) => {
    try {
      res.json(await qAll(
        `SELECT pi.*, i.nome as ingrediente_nome, i.unidade
         FROM produto_ingrediente pi JOIN ingredientes i ON i.id=pi.ingrediente_id
         WHERE pi.product_id=? AND pi.tenant_id=?`,
        [req.params.product_id, req.tenantId]
      ));
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.post('/ficha-tecnica/:product_id', async (req: Request, res) => {
    try {
      const { ingrediente_id, quantidade_usada, unidade } = req.body;
      const existing = await q1('SELECT id FROM produto_ingrediente WHERE product_id=? AND ingrediente_id=? AND tenant_id=?',
        [req.params.product_id, ingrediente_id, req.tenantId]);
      if (existing) {
        await qRun('UPDATE produto_ingrediente SET quantidade_usada=?,unidade=? WHERE product_id=? AND ingrediente_id=? AND tenant_id=?',
          [quantidade_usada, unidade||'unidade', req.params.product_id, ingrediente_id, req.tenantId]);
      } else {
        await qRun('INSERT INTO produto_ingrediente (product_id,ingrediente_id,quantidade_usada,unidade,tenant_id) VALUES (?,?,?,?,?)',
          [req.params.product_id, ingrediente_id, quantidade_usada, unidade||'unidade', req.tenantId]);
      }
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  router.delete('/ficha-tecnica/:product_id/:ingrediente_id', async (req: Request, res) => {
    try {
      await qRun('DELETE FROM produto_ingrediente WHERE product_id=? AND ingrediente_id=? AND tenant_id=?',
        [req.params.product_id, req.params.ingrediente_id, req.tenantId]);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  return router;
}
